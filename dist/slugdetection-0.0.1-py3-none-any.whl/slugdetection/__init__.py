# -*- coding: utf-8 -*-
"""
Part of slugdetection package

@author: Deirdree A Polak
github: dapolak
"""

name = "slugdetection"

import Data_Engineering
import Slug_Labelling
import Flow_Recognition
import Slug_Detection
import SLug_Forecatig